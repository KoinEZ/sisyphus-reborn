$p = Join-Path (Get-Location) 'acsetup.cfg'
if (-not (Test-Path $p)) { [IO.File]::WriteAllText($p, "", [Text.Encoding]::ASCII) }
$t = @(Get-Content $p | Where-Object { $_ -notmatch '^\s*translation\s*=' })
$i = [array]::IndexOf($t, '[language]')
if ($i -lt 0) { $t += '[language]'; $i = $t.Count - 1 }
$new = @()
$new += $t[0..$i]
$new += 'translation=Russian'
if ($i + 1 -lt $t.Count) { $new += $t[($i + 1)..($t.Count - 1)] }
[IO.File]::WriteAllText($p, (($new -join "`r`n") + "`r`n"), [Text.Encoding]::ASCII)
